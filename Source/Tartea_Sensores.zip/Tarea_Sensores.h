

int Init_Thread_Sensores (void) ;
void Sensores_Calibracion_Backgound(void);
void Sensores_Calibracion_Line(void);
